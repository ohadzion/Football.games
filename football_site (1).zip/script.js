
document.getElementById("games").innerText = "כאן יופיעו משחקי היום מהטבלה שלך...";
